Pentru a rula programul:

- make
- mpirun -np 4 ./program

mpirun -np 4 ./program

- Elapsed time: 0.005801 seconds
- Elapsed time: 0.005764 seconds
- Elapsed time: 0.071381 seconds
- Elapsed time: 0.073487 seconds
